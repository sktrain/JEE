Ein Basis Maven Projekt mit aktuellen Plugin-Versionen vom Januar 2023
+ Jupiter-Dependencies
+ Wildfly 32.0.1 Client  für EJB-Zugriff via RMI
+ Wildfly 32.0.1 Client für Zugriff auf JMS
+ Client für Jakarta-WS-Zugriff (EE10)

Kann als Basis für Clients von entsprechenden JEE-serverseitigen Diensten dienen.

Je nach Bedarf können die entsprechenden Dependencies auch raus genommen werden.