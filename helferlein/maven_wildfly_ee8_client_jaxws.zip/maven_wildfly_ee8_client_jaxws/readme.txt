Ein Basis Maven Projekt mit aktuellen Plugin-Versionen vom Januar 2023
+ Jupiter-Dependencies
+ Wildfly 26.1.3 Client
+ JAX-WS  (leider seit Java 11 nicht mehr Bestandteil der SE)