package sk.train;

import javax.ejb.Remote;

@Remote
public interface Datasource {

	String getDsName();

}