package sk.train;

import java.sql.SQLException;

import javax.annotation.PostConstruct;
import javax.annotation.Resource;
import javax.ejb.Stateless;
import javax.sql.DataSource;

@Stateless
public class DatasourceBean implements Datasource {
	
	@Resource(lookup="java:/H2DS4")
	private DataSource ds;
	
	@PostConstruct
	public void init() {
		System.out.println("Datasource: " + ds);
	}
	
	public String getDsName() {
		String s = null;
		try {
			s = ds.getConnection().getMetaData().getDatabaseProductName();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return s;
	}

}
