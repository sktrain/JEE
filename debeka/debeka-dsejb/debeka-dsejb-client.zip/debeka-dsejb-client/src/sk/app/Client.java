package sk.app;

import java.util.Hashtable;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;

import sk.train.Datasource;



public class Client {

	public static void main(String[] args) throws NamingException {
		//NamensContext beschaffen, setzt entsprechende Properties voraus
				final Hashtable<String, String> jndiProperties = new Hashtable<String, String>();
		        jndiProperties.put(Context.URL_PKG_PREFIXES, "org.jboss.ejb.client.naming");
		        final Context context = new InitialContext(jndiProperties);
				//final Context context = new InitialContext();
		        
		        System.out.println("Bis hier ok");
				
				//Client-seitigen Proxy beschaffen
				//Hello stub = (Hello) context.lookup("java:global/EJB_HelloWorld/HelloImpl!sk.train.Hello");
		        Datasource stub = (Datasource) context.lookup("ejb:/debeka-dsejb/DatasourceBean!sk.train.Datasource");
		        
		        System.out.println(stub.getDsName());

	}

}
