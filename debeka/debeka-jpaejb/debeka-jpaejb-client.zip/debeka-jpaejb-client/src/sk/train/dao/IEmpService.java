package sk.train.dao;

import java.math.BigDecimal;
import java.util.List;

import javax.ejb.Remote;

import sk.train.model.Employee;

@Remote
public interface IEmpService {

	void createEmp(long id);

	void createEmp(Employee e);

	Employee readEmp(long id);

	void removeEmp(long id);

	void setSalaryEmp(long id, BigDecimal sal);

	Employee updateEmp(Employee e);

	List<Employee> getAllEmps();

}