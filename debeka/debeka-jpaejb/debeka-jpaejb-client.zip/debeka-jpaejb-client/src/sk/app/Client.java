package sk.app;

import java.util.Hashtable;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;

import sk.train.dao.IEmpService;
import sk.train.model.Employee;



public class Client {

	public static void main(String[] args) throws NamingException {
		//NamensContext beschaffen, setzt entsprechende Properties voraus
				final Hashtable<String, String> jndiProperties = new Hashtable<String, String>();
		        jndiProperties.put(Context.URL_PKG_PREFIXES, "org.jboss.ejb.client.naming");
		        final Context context = new InitialContext(jndiProperties);
				//final Context context = new InitialContext();
		        
		        System.out.println("Bis hier ok");
				
				//Client-seitigen Proxy beschaffen
				//Hello stub = (Hello) context.lookup("java:global/EJB_HelloWorld/HelloImpl!sk.train.Hello");
		        IEmpService stub = (IEmpService) context.lookup("ejb:/debeka-ejbjpa-0.0.1-SNAPSHOT/EmpService!sk.train.dao.IEmpService");
		        
		        Employee e = stub.readEmp(100L);
		        System.out.println(e);
		        
		        System.out.println("\n****************************************************\n");
		        
		        stub.getAllEmps().forEach(System.out::println);

	}

}
