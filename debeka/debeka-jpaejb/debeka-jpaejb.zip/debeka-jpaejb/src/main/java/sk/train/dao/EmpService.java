package sk.train.dao;

import java.math.BigDecimal;
import java.util.Date;
import java.util.List;

import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import sk.train.model.Employee;

@Stateless
public class EmpService implements IEmpService {
	
	@PersistenceContext
	private EntityManager myem;

	
	//default-Konstruktor
	public EmpService() {
		super();		
	}
	
	@Override
	public void createEmp(long id){
		Employee emp = new Employee();
		emp.setEmployeeId(id);
		emp.setFirstName("Max");
		emp.setLastName("Mustermann");
		emp.setHireDate(new Date());
		emp.setJobId("IT_PROG");
		emp.setPhoneNumber("1111");
		emp.setSalary(new BigDecimal(5000l));
		emp.setEmail("Mustermann@murks.de" + id);
		// Rest null		
		myem.persist(emp);		
	}
	
	@Override
	public void createEmp(Employee e) {
		myem.persist(e);
	}
	
	@Override
	public Employee readEmp(long id){
		Employee emp = myem.find(Employee.class, id);
		return emp;
	}
	
	@Override
	public void removeEmp(long id){
		Employee emp = myem.find(Employee.class, id);
		if (emp != null)
		myem.remove(emp);
	}
	
	@Override
	public void setSalaryEmp(long id, BigDecimal sal){
		Employee emp = myem.find(Employee.class, id);
		if (emp != null)
			emp.setSalary(sal);
	}
	
	@Override
	public Employee updateEmp(Employee e) {
		 return myem.merge(e);		
	}
	
	@Override
	public List<Employee> getAllEmps(){
		return myem.createNamedQuery("Employee.findAll").getResultList();
	}
}
