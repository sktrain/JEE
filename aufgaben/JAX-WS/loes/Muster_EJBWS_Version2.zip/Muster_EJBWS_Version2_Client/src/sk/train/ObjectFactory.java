
package sk.train;

import javax.xml.bind.JAXBElement;
import javax.xml.bind.annotation.XmlElementDecl;
import javax.xml.bind.annotation.XmlRegistry;
import javax.xml.namespace.QName;


/**
 * This object contains factory methods for each 
 * Java content interface and Java element interface 
 * generated in the sk.train package. 
 * &lt;p&gt;An ObjectFactory allows you to programatically 
 * construct new instances of the Java representation 
 * for XML content. The Java representation of XML 
 * content can consist of schema derived interfaces 
 * and classes representing the binding of schema 
 * type definitions, element declarations and model 
 * groups.  Factory methods for each of these are 
 * provided in this class.
 * 
 */
@XmlRegistry
public class ObjectFactory {

    private final static QName _GetAllDepartments_QNAME = new QName("http://ws.train.sk/", "getAllDepartments");
    private final static QName _GetAllDepartmentsResponse_QNAME = new QName("http://ws.train.sk/", "getAllDepartmentsResponse");
    private final static QName _GetAllEmps_QNAME = new QName("http://ws.train.sk/", "getAllEmps");
    private final static QName _GetAllEmpsResponse_QNAME = new QName("http://ws.train.sk/", "getAllEmpsResponse");
    private final static QName _GetEmpInDep_QNAME = new QName("http://ws.train.sk/", "getEmpInDep");
    private final static QName _GetEmpInDepResponse_QNAME = new QName("http://ws.train.sk/", "getEmpInDepResponse");
    private final static QName _ReadEmp_QNAME = new QName("http://ws.train.sk/", "readEmp");
    private final static QName _ReadEmpResponse_QNAME = new QName("http://ws.train.sk/", "readEmpResponse");
    private final static QName _RemoveEmp_QNAME = new QName("http://ws.train.sk/", "removeEmp");
    private final static QName _RemoveEmpResponse_QNAME = new QName("http://ws.train.sk/", "removeEmpResponse");
    private final static QName _SaveEmp_QNAME = new QName("http://ws.train.sk/", "saveEmp");
    private final static QName _SaveEmpResponse_QNAME = new QName("http://ws.train.sk/", "saveEmpResponse");
    private final static QName _SetSalaryEmp_QNAME = new QName("http://ws.train.sk/", "setSalaryEmp");
    private final static QName _SetSalaryEmpResponse_QNAME = new QName("http://ws.train.sk/", "setSalaryEmpResponse");

    /**
     * Create a new ObjectFactory that can be used to create new instances of schema derived classes for package: sk.train
     * 
     */
    public ObjectFactory() {
    }

    /**
     * Create an instance of {@link GetAllDepartments }
     * 
     */
    public GetAllDepartments createGetAllDepartments() {
        return new GetAllDepartments();
    }

    /**
     * Create an instance of {@link GetAllDepartmentsResponse }
     * 
     */
    public GetAllDepartmentsResponse createGetAllDepartmentsResponse() {
        return new GetAllDepartmentsResponse();
    }

    /**
     * Create an instance of {@link GetAllEmps }
     * 
     */
    public GetAllEmps createGetAllEmps() {
        return new GetAllEmps();
    }

    /**
     * Create an instance of {@link GetAllEmpsResponse }
     * 
     */
    public GetAllEmpsResponse createGetAllEmpsResponse() {
        return new GetAllEmpsResponse();
    }

    /**
     * Create an instance of {@link GetEmpInDep }
     * 
     */
    public GetEmpInDep createGetEmpInDep() {
        return new GetEmpInDep();
    }

    /**
     * Create an instance of {@link GetEmpInDepResponse }
     * 
     */
    public GetEmpInDepResponse createGetEmpInDepResponse() {
        return new GetEmpInDepResponse();
    }

    /**
     * Create an instance of {@link ReadEmp }
     * 
     */
    public ReadEmp createReadEmp() {
        return new ReadEmp();
    }

    /**
     * Create an instance of {@link ReadEmpResponse }
     * 
     */
    public ReadEmpResponse createReadEmpResponse() {
        return new ReadEmpResponse();
    }

    /**
     * Create an instance of {@link RemoveEmp }
     * 
     */
    public RemoveEmp createRemoveEmp() {
        return new RemoveEmp();
    }

    /**
     * Create an instance of {@link RemoveEmpResponse }
     * 
     */
    public RemoveEmpResponse createRemoveEmpResponse() {
        return new RemoveEmpResponse();
    }

    /**
     * Create an instance of {@link SaveEmp }
     * 
     */
    public SaveEmp createSaveEmp() {
        return new SaveEmp();
    }

    /**
     * Create an instance of {@link SaveEmpResponse }
     * 
     */
    public SaveEmpResponse createSaveEmpResponse() {
        return new SaveEmpResponse();
    }

    /**
     * Create an instance of {@link SetSalaryEmp }
     * 
     */
    public SetSalaryEmp createSetSalaryEmp() {
        return new SetSalaryEmp();
    }

    /**
     * Create an instance of {@link SetSalaryEmpResponse }
     * 
     */
    public SetSalaryEmpResponse createSetSalaryEmpResponse() {
        return new SetSalaryEmpResponse();
    }

    /**
     * Create an instance of {@link Employee }
     * 
     */
    public Employee createEmployee() {
        return new Employee();
    }

    /**
     * Create an instance of {@link Timestamp }
     * 
     */
    public Timestamp createTimestamp() {
        return new Timestamp();
    }

    /**
     * Create an instance of {@link Department }
     * 
     */
    public Department createDepartment() {
        return new Department();
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link GetAllDepartments }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link GetAllDepartments }{@code >}
     */
    @XmlElementDecl(namespace = "http://ws.train.sk/", name = "getAllDepartments")
    public JAXBElement<GetAllDepartments> createGetAllDepartments(GetAllDepartments value) {
        return new JAXBElement<GetAllDepartments>(_GetAllDepartments_QNAME, GetAllDepartments.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link GetAllDepartmentsResponse }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link GetAllDepartmentsResponse }{@code >}
     */
    @XmlElementDecl(namespace = "http://ws.train.sk/", name = "getAllDepartmentsResponse")
    public JAXBElement<GetAllDepartmentsResponse> createGetAllDepartmentsResponse(GetAllDepartmentsResponse value) {
        return new JAXBElement<GetAllDepartmentsResponse>(_GetAllDepartmentsResponse_QNAME, GetAllDepartmentsResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link GetAllEmps }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link GetAllEmps }{@code >}
     */
    @XmlElementDecl(namespace = "http://ws.train.sk/", name = "getAllEmps")
    public JAXBElement<GetAllEmps> createGetAllEmps(GetAllEmps value) {
        return new JAXBElement<GetAllEmps>(_GetAllEmps_QNAME, GetAllEmps.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link GetAllEmpsResponse }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link GetAllEmpsResponse }{@code >}
     */
    @XmlElementDecl(namespace = "http://ws.train.sk/", name = "getAllEmpsResponse")
    public JAXBElement<GetAllEmpsResponse> createGetAllEmpsResponse(GetAllEmpsResponse value) {
        return new JAXBElement<GetAllEmpsResponse>(_GetAllEmpsResponse_QNAME, GetAllEmpsResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link GetEmpInDep }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link GetEmpInDep }{@code >}
     */
    @XmlElementDecl(namespace = "http://ws.train.sk/", name = "getEmpInDep")
    public JAXBElement<GetEmpInDep> createGetEmpInDep(GetEmpInDep value) {
        return new JAXBElement<GetEmpInDep>(_GetEmpInDep_QNAME, GetEmpInDep.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link GetEmpInDepResponse }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link GetEmpInDepResponse }{@code >}
     */
    @XmlElementDecl(namespace = "http://ws.train.sk/", name = "getEmpInDepResponse")
    public JAXBElement<GetEmpInDepResponse> createGetEmpInDepResponse(GetEmpInDepResponse value) {
        return new JAXBElement<GetEmpInDepResponse>(_GetEmpInDepResponse_QNAME, GetEmpInDepResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link ReadEmp }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link ReadEmp }{@code >}
     */
    @XmlElementDecl(namespace = "http://ws.train.sk/", name = "readEmp")
    public JAXBElement<ReadEmp> createReadEmp(ReadEmp value) {
        return new JAXBElement<ReadEmp>(_ReadEmp_QNAME, ReadEmp.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link ReadEmpResponse }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link ReadEmpResponse }{@code >}
     */
    @XmlElementDecl(namespace = "http://ws.train.sk/", name = "readEmpResponse")
    public JAXBElement<ReadEmpResponse> createReadEmpResponse(ReadEmpResponse value) {
        return new JAXBElement<ReadEmpResponse>(_ReadEmpResponse_QNAME, ReadEmpResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link RemoveEmp }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link RemoveEmp }{@code >}
     */
    @XmlElementDecl(namespace = "http://ws.train.sk/", name = "removeEmp")
    public JAXBElement<RemoveEmp> createRemoveEmp(RemoveEmp value) {
        return new JAXBElement<RemoveEmp>(_RemoveEmp_QNAME, RemoveEmp.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link RemoveEmpResponse }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link RemoveEmpResponse }{@code >}
     */
    @XmlElementDecl(namespace = "http://ws.train.sk/", name = "removeEmpResponse")
    public JAXBElement<RemoveEmpResponse> createRemoveEmpResponse(RemoveEmpResponse value) {
        return new JAXBElement<RemoveEmpResponse>(_RemoveEmpResponse_QNAME, RemoveEmpResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link SaveEmp }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link SaveEmp }{@code >}
     */
    @XmlElementDecl(namespace = "http://ws.train.sk/", name = "saveEmp")
    public JAXBElement<SaveEmp> createSaveEmp(SaveEmp value) {
        return new JAXBElement<SaveEmp>(_SaveEmp_QNAME, SaveEmp.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link SaveEmpResponse }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link SaveEmpResponse }{@code >}
     */
    @XmlElementDecl(namespace = "http://ws.train.sk/", name = "saveEmpResponse")
    public JAXBElement<SaveEmpResponse> createSaveEmpResponse(SaveEmpResponse value) {
        return new JAXBElement<SaveEmpResponse>(_SaveEmpResponse_QNAME, SaveEmpResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link SetSalaryEmp }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link SetSalaryEmp }{@code >}
     */
    @XmlElementDecl(namespace = "http://ws.train.sk/", name = "setSalaryEmp")
    public JAXBElement<SetSalaryEmp> createSetSalaryEmp(SetSalaryEmp value) {
        return new JAXBElement<SetSalaryEmp>(_SetSalaryEmp_QNAME, SetSalaryEmp.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link SetSalaryEmpResponse }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link SetSalaryEmpResponse }{@code >}
     */
    @XmlElementDecl(namespace = "http://ws.train.sk/", name = "setSalaryEmpResponse")
    public JAXBElement<SetSalaryEmpResponse> createSetSalaryEmpResponse(SetSalaryEmpResponse value) {
        return new JAXBElement<SetSalaryEmpResponse>(_SetSalaryEmpResponse_QNAME, SetSalaryEmpResponse.class, null, value);
    }

}
