JAX-WS-Client unter Java 11:

- Da wsimport-Tool nicht mehr dabei, muss dieses jetzt extern besorgt werden (z.B. jax-ws-ri)
oder aber wsconsume vom Wildfly benutzt werden, was wiederum wsdl2java von Apache CXF aufruft.

- Leider versteht Java 11 den gebnerierten Code nicht, da dieser WS-Annotiert ist.
Somit müssen JAX-WS-Bibliotheken auf der Client-Seite bereit gestellt werden. Hier wird
jax-ws-ri (Metro) in der Version 2.3.1 benutzt. Allerdings enthält die wiederum nicht alles.
Deshalb Eclipse-Vorschlag: jsr181-api-1.0-MR1.jar zusätzlich.