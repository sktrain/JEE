package sk.train;

import java.time.LocalDate;

import javax.annotation.PostConstruct;
import javax.jws.WebMethod;
import javax.jws.WebService;

@WebService  //ist notwendig beim Java 8 Client
public interface HelloWorld {
	
//	
	public void init();


//	@WebMethod
	public String sayHello(String name) ;
	
//	@WebMethod
	public LocalDate sayDate();
	
	public String sayDateasString();
}
