Läuft auf Wildfly 24.
Der Service ist ohne Interface und Java 11 kompiliert (geht bei Wildfly 24).
Wie man anhand der generierten WSDL sieht, ist dann auch die public init-Methode angeboten!
(auch wenn diese keine @WebMethod trägt). Von daher ist @WebMethod in dieser Form überflüssig!
Auch mit LocalDate kommt diese JAX-WS-Version (bzw. JAXB) nicht klar. Bei direkter Verwendung
enthält die Antwort keinen Datumstring!