package sk.train;

import java.time.LocalDateTime;

import javax.annotation.PostConstruct;
import javax.jws.WebMethod;
import javax.jws.WebService;

@WebService
public class HelloWorld {
	
	private LocalDateTime ldate;
	
	@PostConstruct
	public void init() {
		ldate = LocalDateTime.now();
	}

	@WebMethod
	public String sayHello(String name) {
	    System.out.println("Hello: " + name);
	    return "Hello " + name + "!";
	}
	
	@WebMethod
	public LocalDateTime sayDate() {
		return ldate;
	}
	
	@WebMethod
	public String sayDateasString() {
		//return ldate;
		return ldate.toString();
	}
}
