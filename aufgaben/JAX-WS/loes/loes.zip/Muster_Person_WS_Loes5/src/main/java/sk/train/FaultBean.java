package sk.train;

public class FaultBean {
	
	private String info;

	public FaultBean() {
		super();
	}

	public String getInfo() {
		return info;
	}

	public void setInfo(String info) {
		this.info = info;
	}

	
}
