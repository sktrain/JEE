
Client für  den JAX-WS Person_WS mit Berücksichtigung des Web-Fault in der generierten Variante.
Die Coded-Variante bekommt auf der Client-Seite RuntimeException.

