package sk.train;


//@XmlAccessorType(XmlAccessType.FIELD)
public class Person {
	
	public enum Geschlecht { W, M, U

	};
	
	private String name;
	//@XmlJavaTypeAdapter(type = LocalDate.class,value=LocalDateAdapter.class)
	//private LocalDate birthdate;
	private Geschlecht g;
	
	
	public Person() {
		super();
	}
	
	public String getName() {
		return name;
	}
	
	public void setName(String name) {
		this.name = name;
	}
	
//	public LocalDate getBirthdate() {
//		return birthdate;
//	}
	
//	public void setBirthdate(LocalDate birthdate) {
//		this.birthdate = birthdate;
//	}
	
	public Geschlecht getG() {
		return g;
	}
	public void setG(Geschlecht g) {
		this.g = g;
	}

	@Override
	public String toString() {
		return "Person [name=" + name 
//				+ ", birthdate=" + birthdate 
				+ ", g=" + g + "]";
	}
	
	
}
