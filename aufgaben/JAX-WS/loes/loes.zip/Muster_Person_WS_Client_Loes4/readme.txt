
Client für  den JAX-WS Person_WS mit Zugriff auf BindingProvider.

