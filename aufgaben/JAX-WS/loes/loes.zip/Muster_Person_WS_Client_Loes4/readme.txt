Ein Basis Maven Projekt mit aktuellen Plugin-Versionen vom Januar 2023
+ Jupiter-Dependencies
+ Client für Jakarta-WS-Zugriff (EE10)

Client für  den erweiterten JAX-WS Person_WS_erweitert, 
der ebenfalls via BindingProvider auf die darunterliegenden Layer zugreift.
(DI des WebServiceContext steht hier ja nicht zur Verfügung!)
