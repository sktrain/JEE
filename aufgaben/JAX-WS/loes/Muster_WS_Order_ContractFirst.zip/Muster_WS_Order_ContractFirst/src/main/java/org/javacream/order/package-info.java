@jakarta.xml.bind.annotation.XmlSchema(namespace = "http://javacream.org/order/", elementFormDefault = jakarta.xml.bind.annotation.XmlNsForm.QUALIFIED)
package org.javacream.order;
