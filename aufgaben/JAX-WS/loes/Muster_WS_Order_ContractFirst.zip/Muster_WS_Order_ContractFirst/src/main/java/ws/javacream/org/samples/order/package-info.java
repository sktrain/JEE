@jakarta.xml.bind.annotation.XmlSchema(namespace = "http://org.javacream.ws/samples/order", elementFormDefault = jakarta.xml.bind.annotation.XmlNsForm.QUALIFIED)
package ws.javacream.org.samples.order;
