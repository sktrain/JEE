

Ein Basis Maven Projekt mit aktuellen Plugin-Versionen vom Januar 2023
+ Jupiter-Dependencies
+ Client für Jakarta-WS-Zugriff (EE10)

Client für  den JAX-WS SOAPHandler ohne explizite Code-Generierung.
Der Client setzt einen Header mit Token (als String)

