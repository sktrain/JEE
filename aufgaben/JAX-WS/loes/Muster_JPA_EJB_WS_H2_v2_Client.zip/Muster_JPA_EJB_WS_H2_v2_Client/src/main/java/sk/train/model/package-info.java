@jakarta.xml.bind.annotation.XmlSchema(namespace = "http://ws.train.sk/")
package sk.train.model;
