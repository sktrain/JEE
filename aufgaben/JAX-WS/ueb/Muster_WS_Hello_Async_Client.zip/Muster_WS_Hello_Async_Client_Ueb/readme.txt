Übung:

Es ist ein asynchroner Client für den Web-Service zu erstellen.
Die entsprechende Binding-Datei für die Erzeugung der asynchronen
Varianten bei der Code-Generierung liegt bereits bei.



(Ein Basis Maven Projekt mit aktuellen Plugin-Versionen vom Januar 2023
+ Jupiter-Dependencies
+ Client für Jakarta-WS-Zugriff (EE10) )