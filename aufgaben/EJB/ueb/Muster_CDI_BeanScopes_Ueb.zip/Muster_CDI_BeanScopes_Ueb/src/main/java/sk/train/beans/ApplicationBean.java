package sk.train.beans;

import java.time.LocalTime;

import jakarta.annotation.PostConstruct;
import jakarta.enterprise.context.ApplicationScoped;
import jakarta.inject.Inject;

@ApplicationScoped
public class ApplicationBean {
	
	//todo
	
	

}
