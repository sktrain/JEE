package sk.train.beans;

import java.time.LocalTime;

import jakarta.annotation.PostConstruct;
import jakarta.enterprise.context.SessionScoped;
import jakarta.inject.Inject;
import java.io.Serializable;

@SessionScoped()
public class SessionBean implements Serializable {
	
	private static final long serialVersionUID = 1L;

	//todo
	

}
