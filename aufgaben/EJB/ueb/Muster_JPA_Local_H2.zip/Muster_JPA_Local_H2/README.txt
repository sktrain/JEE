==========================

Basis JPA Projekt mit Mapping der DEPARTMENTS- und EMPLOYEES-Tabellen inklusive
Fremdschlüsselbeziehungen auf Basis des HR-Schemas in einer  H2-Database.


Nebenbei bemerkt:
Hier  stellt  sich schon die Frage, ob die Eager-Beziehungen sinnvoll sind
(siehe Hibernate-SELECTs).

==========================


