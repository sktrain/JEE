Bei Konstruktor-Injektion muss der Qualifier vor den Parameter geschrieben werden!
->  Das muss die Annotation auch erlauben.
