package sk.train.beans;


import sk.train.ifaces.Instrument;


public class Klavier implements Instrument{
	
	public Klavier(){
		super();
	}
	
	public void play() {
		System.out.println("Klavierklänge von " + this);
	}
}

