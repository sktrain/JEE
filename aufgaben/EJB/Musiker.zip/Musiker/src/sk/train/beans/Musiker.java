package sk.train.beans;


import sk.train.ifaces.Instrument;
import sk.train.ifaces.Performer;

public class Musiker implements Performer{	
	
	private Instrument i;
	

	public Musiker(Instrument i) {
		this.i = i;
	}
	
	public void perform() {
		System.out.println("Performamce von " + this);
		i.play();
	}
}
