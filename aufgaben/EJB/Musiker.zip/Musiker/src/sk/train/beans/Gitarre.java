package sk.train.beans;

import sk.train.ifaces.Instrument;

public class Gitarre implements Instrument{
	
	public Gitarre(){
		super();
	}
	
	public void play() {
		System.out.println("Gitarrenklänge");
	}
}