package sk.train.ifaces;

public interface Instrument {
	public abstract void play();
}

