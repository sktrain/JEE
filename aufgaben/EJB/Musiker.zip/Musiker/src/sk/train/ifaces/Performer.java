package sk.train.ifaces;

public interface Performer {
	public abstract void perform();
}
