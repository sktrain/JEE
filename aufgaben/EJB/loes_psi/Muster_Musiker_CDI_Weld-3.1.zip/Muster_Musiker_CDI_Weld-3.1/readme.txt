Die benötigten Weld-JArs befinden sich im lib-Ordner des Projekts

Bei Konstruktor-Injektion muss der Qualifier vor den Parameter geschrieben werden!
->  Das muss die Annotation auch erlauben.

Bzgl. Funktionalität: Der Aufgerufene bestimmt, was injiziert wird. -> Es ist entweder Gitarrist oder Klavierspieler.