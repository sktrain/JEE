package sk.train.beans;

import java.time.LocalTime;

import javax.annotation.PostConstruct;
import javax.enterprise.context.ApplicationScoped;
import javax.inject.Inject;

@ApplicationScoped
public class ApplicationBean {
	
	//todo
	
	

}
