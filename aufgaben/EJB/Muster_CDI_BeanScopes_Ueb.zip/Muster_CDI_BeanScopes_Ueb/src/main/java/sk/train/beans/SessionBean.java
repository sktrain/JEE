package sk.train.beans;

import java.time.LocalTime;

import javax.annotation.PostConstruct;
import javax.enterprise.context.SessionScoped;
import javax.inject.Inject;
import java.io.Serializable;

@SessionScoped()
public class SessionBean implements Serializable {
	
	private static final long serialVersionUID = 1L;

	//todo
	

}
