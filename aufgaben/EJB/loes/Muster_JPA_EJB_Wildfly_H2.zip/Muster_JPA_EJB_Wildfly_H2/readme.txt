Ist gleich Dynamic Web Project in Eclipse für zukünftige Erweiterungen (Web-Layer),
da man diese Facette in Eclipse nicht nachträglich hinzufügen kann.