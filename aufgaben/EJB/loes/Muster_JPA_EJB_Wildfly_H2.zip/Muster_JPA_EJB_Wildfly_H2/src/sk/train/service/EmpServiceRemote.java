package sk.train.service;

import java.math.BigDecimal;
import java.util.List;

import javax.ejb.Remote;

import sk.train.model.Department;
import sk.train.model.Employee;

@Remote
public interface EmpServiceRemote {

	void saveEmp(Employee emp);

	Employee readEmp(long id);

	void removeEmp(long id);

	void setSalaryEmp(long id, BigDecimal sal);

	List<Employee> getEmpInDep(long departmentid);

	List<Employee> getAllEmps();

	List<Department> getAllDepartments();

}