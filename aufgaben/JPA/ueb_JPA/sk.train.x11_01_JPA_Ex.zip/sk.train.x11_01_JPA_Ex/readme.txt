Aufgabe:

Zu gegebener Entity "Employee" mit entsprechender Tabelle in der H2-Datenbank,
soll ein entsprechendes rudimentäres Repository "EmpService" erstellt werden
(gegebener Code ist zu komplettieren und kann bei Bedarf erweitert werden).

Anschließend soll der JPA-Layer mal via Starter-Klasse initialisiert und das
Repository genutzt werden.