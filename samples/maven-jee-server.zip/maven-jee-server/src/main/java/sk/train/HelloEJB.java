package sk.train;

import javax.ejb.Stateless;

//import javax.ejb.Stateless;

/**
 * Session Bean implementation class HelloEJB
 */
@Stateless
public class HelloEJB implements HelloEJBRemote {

    /**
     * Default constructor. 
     */
    public HelloEJB() {
        // TODO Auto-generated constructor stub
    }
    
    public String get(String input) {
    	return "Hallo " + input;
    }

}
