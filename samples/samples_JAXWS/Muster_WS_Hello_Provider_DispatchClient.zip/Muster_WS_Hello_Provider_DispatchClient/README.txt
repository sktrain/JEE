
Dispatch-Client für den simplen HelloProvider.


