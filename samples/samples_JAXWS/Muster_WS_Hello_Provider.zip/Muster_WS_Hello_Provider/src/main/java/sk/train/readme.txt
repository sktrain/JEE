Ein Basis Maven Projekt mit aktuellen Plugin-Versionen vom Januar 2023
+ Jupiter-Dependencies
+ Client für Jakarta-WS-Zugriff (EE10)

Dispatch-Client für  den JAX-WS Hello_WS_Provider.


