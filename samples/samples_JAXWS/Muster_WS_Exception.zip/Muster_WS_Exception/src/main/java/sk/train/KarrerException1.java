package sk.train;

public class KarrerException1 extends Exception {
	
	public KarrerException1(String reason) {
		super(reason);		
	}

	public KarrerException1() {
		super();
		// TODO Auto-generated constructor stub
	}

	public KarrerException1(String message, Throwable cause, boolean enableSuppression, boolean writableStackTrace) {
		super(message, cause, enableSuppression, writableStackTrace);
		// TODO Auto-generated constructor stub
	}

	public KarrerException1(String message, Throwable cause) {
		super(message, cause);
		// TODO Auto-generated constructor stub
	}

	public KarrerException1(Throwable cause) {
		super(cause);
		// TODO Auto-generated constructor stub
	}
	
}
