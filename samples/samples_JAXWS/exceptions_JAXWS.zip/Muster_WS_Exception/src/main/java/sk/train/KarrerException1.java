package sk.train;

public class KarrerException1 extends Exception {
	
	public KarrerException1(String reason) {
		super(reason);		
	}
	
}
