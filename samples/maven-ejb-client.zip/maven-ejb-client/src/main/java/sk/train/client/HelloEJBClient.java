package sk.train.client;



import java.util.Hashtable;
import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import sk.train.HelloEJBRemote;

public class HelloEJBClient {

	public static void main(String[] args) throws NamingException {
		// NamensContext beschaffen, setzt entsprechende Properties voraus
		final Hashtable<String, String> jndiProperties = new Hashtable<String, String>();
		jndiProperties.put(Context.URL_PKG_PREFIXES, "org.jboss.ejb.client.naming");
		//java.naming.provider.url=jnp://yourServer:1099
		
		final Context context = new InitialContext(jndiProperties);
		// final Context context = new InitialContext();
		
//		System.out.println("Bis hier ok");
//		System.out.println(context.URL_PKG_PREFIXES);
//		System.out.println(context.PROVIDER_URL);
//		System.out.println(context);
		//context.getEnvironment().forEach((key, value) -> System.out.println(key + "=" + value));
		

		// Client-seitigen Proxy beschaffen
		
		HelloEJBRemote stub = (HelloEJBRemote) 
				context.lookup("ejb:/debeka-ejbjpa-0.0.1-SNAPSHOT/HelloEJB!sk.train.HelloEJBRemote");
		
		System.out.println(stub.get("Stephan"));   
		

	}

}
