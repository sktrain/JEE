package sk.train;

import javax.ejb.Remote;

//import javax.ejb.Remote;

@Remote
public interface HelloEJBRemote {
	
	public String get(String input);

}
