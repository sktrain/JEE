This project was created from the archetype "wildfly-jakartaee-webapp-archetype"
and customized for our exercises.

To deploy it:
Run the maven goals "install wildfly:deploy"

To undeploy it:
Run the maven goals "wildfly:undeploy"

==========================

DataSource:
This sample includes a "persistence.xml" file in "src/main/resources/META-INF". This file defines
a persistence unit "maven_wildfly_ee8PersistenceUnit" which uses the JakartaEE default database.

In production environment, you should define a database in WildFly config and point to this database
in "persistence.xml".

If you don't use entity beans, you can delete "persistence.xml".
==========================

CDI:
The web application is prepared for CDI 2.0 by bundling an "beans.xml" in "src/main/webapp/WEB-INF".

==========================


