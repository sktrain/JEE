Samples zur Java SE auf
Basis eines Maven Projekts mit aktuellen Plugin-Versionen vom Januar 2023
+ Jupiter-Dependencies
