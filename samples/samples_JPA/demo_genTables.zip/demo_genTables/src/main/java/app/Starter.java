package app;

import javax.persistence.Persistence;

public class Starter {
    public static void main(String[] args) {
        Persistence.createEntityManagerFactory("persistenceUnit");
    }
}
