==========================

Basis JPA Projekt mit Mapping der DEPARTMENTS- und EMPLOYEES-Tabellen inklusive
Fremdschlüsselbeziehungen auf Basis des HR-Schemas in einer  H2-Database.


Mit Nutzung eines Transaction-Template!
(sowas ist ab Jakarta JPA 3.2 (Sep. 2023) bereits vorhanden)

==========================


