package sk.train.dao;

import javax.persistence.EntityManager;

public interface DaoIf {
	
	void setEntityManager(EntityManager em);
}
