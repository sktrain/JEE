==========================

Basis JPA Projekt mit Mapping der DEPARTMENTS- und EMPLOYEES-Tabellen inklusive
Fremdschlüsselbeziehungen auf Basis des HR-Schemas in einer  H2-Database.

Mit Nutzung eines transaktionalen Proxies!


==========================


