Samples zum DB-Zugriff via JDBC auf
Basis eines Maven Projekts mit aktuellen Plugin-Versionen vom Januar 2023
+ Jupiter-Dependencies
