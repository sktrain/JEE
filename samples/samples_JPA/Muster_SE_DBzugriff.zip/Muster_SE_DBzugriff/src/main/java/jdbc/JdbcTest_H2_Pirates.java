/* JDBC_Zugriff auf Oracle Express
 * Voraussetzung: JAR-Datei mit JDBC-Driver ist im Classpath,
 * das DBMS l�uft und die Zugangsinfos stimmen
 */

package jdbc;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.nio.charset.Charset;
import java.nio.charset.StandardCharsets;
import java.sql.*;


//import oracle.jdbc.*;


public class JdbcTest_H2_Pirates {

    private static String ddl;

    private void createDDL() throws IOException {
        ddl = new String(this.getClass().getClassLoader().getResourceAsStream("script.sql").readAllBytes(), StandardCharsets.UTF_8);
    }

    public static void main(String[] args) {

        //DriverManager.setLogWriter(new PrintWriter(System.out));

        DriverManager.drivers().forEach(System.err::println);

        //Schritt 1: Laden des Treibers (passiert bei aktuellen Treibern via ServiceLoader-Mechanismus

//				try {
//					Class.forName("org.h2.Driver");
//				} catch (Exception e) {
//					// TODO Auto-generated catch block
//					e.printStackTrace();
//				}
        //DriverManager.registerDriver(new org.h2.Driver());

        //Schritt 2: da Connection AutoCloseable ->  try mit Ressourcen
        try (Connection myconnect =
                     DriverManager.getConnection("jdbc:h2:tcp://localhost/~/test", "sa", "");) {


            //Schritt 3: SQL-Anweisungen absetzen
            System.out.println(myconnect.getMetaData().getDatabaseProductName());
            Statement st = myconnect.createStatement();

            new JdbcTest_H2_Pirates().createDDL();
            //String ddl = new String(new JdbcTest_H2_Pirates().getClass().getClassLoader().getResourceAsStream("script.sql").readAllBytes(), StandardCharsets.UTF_8);
                    //new BufferedReader(new InputStreamReader(JdbcTest_H2_Pirates.class.getResourceAsStream("/script.sql"))).lines().reduce("", (red, string) -> red + string);

            System.err.println(ddl);

            st.execute(ddl);
//            int anzahlspalten = rs.getMetaData().getColumnCount();
//            System.out.println("Insgesamt Spalten verfügbar: " + anzahlspalten);
//            while (rs.next()) {
//                System.out.println(rs.getString(1) + " | " + rs.getString(2));
//            }

            PreparedStatement ps = myconnect
                    .prepareStatement("INSERT INTO Pirate (nickname, email, swordlength, birthdate, description)\n" +
                            "VALUES ('CiaoCiao', 'captain@goldenpirates.faith', 18, DATE '1955-11-07', 'Great guy')");

            ps.executeUpdate();

            ResultSet rs = st.executeQuery("SELECT * FROM PIRATE ");
            ResultSetMetaData rsmd = rs.getMetaData();
            System.out.println(rsmd.getColumnName(1) + "\t:\t" + rsmd.getColumnName(2));
            rs.next();
            System.out.println(rs.getString(1) + "\t:\t" + rs.getString(2));

        } catch (SQLException e) {
            e.printStackTrace();
        } catch (Exception e) {
            throw new RuntimeException(e);
        }

    }


}
