Dieses Beispiel läuft sowohl auf EAP 6.x, EAP 7.x, 
als auch Wildfly 8, 9, 10, 11, 15, 19, 24
Voraussetzung: Die Datasource ist eingerichtet und der DB-Server läuft

Wildfly 24 läuft auf Java 11 und führt auch Java 11 Code aus!




This project was created from the archetype "wildfly-jakartaee-webapp-archetype".

To deploy it:
Run the maven goals "install wildfly:deploy"

To undeploy it:
Run the maven goals "wildfly:undeploy"


