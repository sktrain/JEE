Dieses Beispiel l�uft mit Wildfly 19 sowie 24 und nutzt CDI2.0 mit
bean-discovery-mode="annotated" statt bean-discovery-mode="all". 
Somit müssen potentielle Beans annotiert werden!
siehe: http://www.mastertheboss.com/jboss-frameworks/cdi/configuring-beans-xml-file/
   bzw.  https://docs.jboss.org/cdi/spec/1.2/cdi-spec-1.2.pdf



This project was created from the archetype "wildfly-jakartaee-webapp-archetype".

To deploy it:
Run the maven goals "install wildfly:deploy"

To undeploy it:
Run the maven goals "wildfly:undeploy"



