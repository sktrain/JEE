package sk.train.sample;

public interface EmptyIf {	

}
