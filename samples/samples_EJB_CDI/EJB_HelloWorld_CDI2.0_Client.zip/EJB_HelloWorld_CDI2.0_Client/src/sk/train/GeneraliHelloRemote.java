package sk.train;

import javax.ejb.Remote;


public interface GeneraliHelloRemote {
	
	public abstract String sayHallo(String input);

}
