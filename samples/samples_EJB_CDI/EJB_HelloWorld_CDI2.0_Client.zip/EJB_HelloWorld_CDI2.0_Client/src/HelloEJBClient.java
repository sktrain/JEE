


import java.util.Hashtable;
import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;

import sk.train.GeneraliHelloRemote;

public class HelloEJBClient {

	public static void main(String[] args) throws NamingException {
		// NamensContext beschaffen, setzt entsprechende Properties voraus
		final Hashtable<String, String> jndiProperties = new Hashtable<String, String>();
		jndiProperties.put(Context.URL_PKG_PREFIXES, "org.jboss.ejb.client.naming");
		//java.naming.provider.url=jnp://yourServer:1099
		
		final Context context = new InitialContext(jndiProperties);
		// final Context context = new InitialContext();
		

		// Client-seitigen Proxy beschaffen
		
		GeneraliHelloRemote stub = (GeneraliHelloRemote) 
				context.lookup("ejb:/EJB_HelloWorld_CDI2.0_maven_wildfly_ee8/GeneraliHello!sk.train.GeneraliHelloRemote");
		
		System.out.println(stub.sayHallo("Stephan"));
		
		// Wie folgende Ausgabe zeigt, ist das stub-Objekt ein Proxy,
		// der  für uns die Netzwerkkommunikation via RMi erledigt
		System.out.println(stub.getClass());
		

	}

}
