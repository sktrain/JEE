package sk.train;

import javax.ejb.Remote;


public interface HelloRemote {
	
	public abstract String sayHallo(String input);

}
