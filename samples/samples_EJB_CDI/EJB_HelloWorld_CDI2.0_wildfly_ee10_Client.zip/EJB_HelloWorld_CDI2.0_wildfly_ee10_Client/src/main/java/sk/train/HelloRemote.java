package sk.train;

public interface HelloRemote {
	
	public abstract String sayHallo(String input);

}
