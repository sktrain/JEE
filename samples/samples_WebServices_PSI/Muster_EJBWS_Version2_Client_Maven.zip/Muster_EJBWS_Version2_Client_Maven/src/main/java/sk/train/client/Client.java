package sk.train.client;

import sk.train.EmpServiceIf;
import sk.train.EmpWebServiceService;
import sk.train.Employee;

public class Client {

	public static void main(String[] args) {

		EmpWebServiceService serv = new EmpWebServiceService();
		
		EmpServiceIf stub = serv.getEmpWebServicePort();
		
		Employee e = stub.readEmp(100L);
		System.out.println(e.getLastName());

		stub.getAllEmps().forEach(emp -> System.out.println(emp.getLastName()));
		
		System.out.println("\n********************************************************\n");
		
		stub.getEmpInDep(50L).forEach(emp -> System.out.println(emp.getLastName()));

	}

}
