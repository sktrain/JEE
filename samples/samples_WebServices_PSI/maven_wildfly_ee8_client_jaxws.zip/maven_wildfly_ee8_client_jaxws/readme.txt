Ein Basis Maven Projekt mit aktuellen Plugin-Versionen vom Januar 2023
+ Jupiter-Dependencies
+ Wildfly24.x Client
+ JAX-WS  (leider seit Java 11 nicht mehr Bestandteil der SE)