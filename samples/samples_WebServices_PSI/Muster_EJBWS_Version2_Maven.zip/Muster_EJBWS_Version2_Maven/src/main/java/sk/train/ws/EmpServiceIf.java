package sk.train.ws;

import java.math.BigDecimal;
import java.util.List;

import javax.jws.WebService;

import sk.train.model.Department;
import sk.train.model.Employee;

@WebService
public interface EmpServiceIf {

	void saveEmp(Employee emp);

	Employee readEmp(long id);

	void removeEmp(long id);

	void setSalaryEmp(long id, BigDecimal sal);

	List<Employee> getEmpInDep(long departmentid);

	List<Employee> getAllEmps();

	List<Department> getAllDepartments();

}