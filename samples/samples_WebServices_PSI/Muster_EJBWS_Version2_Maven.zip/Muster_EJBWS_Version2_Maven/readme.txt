This project was created from the archetype "wildfly-jakartaee-webapp-archetype"
and customized for our exercises.

To deploy it:
Run the maven goals "install wildfly:deploy"

To undeploy it:
Run the maven goals "wildfly:undeploy"

==================================================================================================

Kombination von EJB, die den DB-Zugriff mittels JPA realisiert, und dem WebService

Bereinigt um Abhängigkeiten in und zwischen den Tabellen, 
d.h. Schlüssel-Fremdschlüssel-Beziehungen werden nicht mit JPA abgebildet


