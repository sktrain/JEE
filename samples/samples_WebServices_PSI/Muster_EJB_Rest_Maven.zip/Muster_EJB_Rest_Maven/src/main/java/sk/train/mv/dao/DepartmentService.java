package sk.train.mv.dao;

import java.util.List;

import javax.ejb.Local;

import model.Department;

@Local
public interface DepartmentService {

	Department getDepartment(long department_id);

	void createDepartment(long department_id, String department_name);

	void removeDepartment(long department_id);

	List<Department> getallDepartments();

}