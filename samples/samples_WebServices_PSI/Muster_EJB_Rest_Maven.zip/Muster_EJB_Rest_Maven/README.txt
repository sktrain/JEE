This project was created from the archetype "wildfly-jakartaee-webapp-archetype"
and customized for our exercises.

To deploy it:
Run the maven goals "install wildfly:deploy"

To undeploy it:
Run the maven goals "wildfly:undeploy"


Aufruf im Browser z.Bsp:   http://localhost:8080/Muster_EJB_Rest_Maven/rest/departmentserv/getall

==========================
JPA+EJB mit Rest-Frontend



