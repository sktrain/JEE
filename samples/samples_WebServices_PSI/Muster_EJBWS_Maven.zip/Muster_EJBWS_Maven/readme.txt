This project was created from the archetype "wildfly-jakartaee-webapp-archetype"
and customized for our exercises.

To deploy it:
Run the maven goals "install wildfly:deploy"

To undeploy it:
Run the maven goals "wildfly:undeploy"

==================================================================================================

Kombination von EJB, die den DB-Zugriff mittels JPA realisiert, und dem WebService

!! Allerdings gibt es bei den Zugriffen durch Clients generell eine Exception, da JAXB auf 
der Serverseite zur Laufzeit keine zyklischen Abh�ngigkeiten in XML-Konstrukte abbilden kann !!

(Ursache:  Employee-Objekt verweist auf Department-Objekt, welches wiederum auf Employee-Objekt verweist,
da die Schl�sselbeziehungen bidirektional zgl. JPA abgebildet wurden)

Mögliche Strategien zur Fehlerbehebung siehe 
https://www.ibm.com/developerworks/rational/library/resolve-jaxb-cycle-errors/index.html 

oder aber generelle Vermeidung von direktem Austausch von Objekten der Entitätsklassen !


