package sk.train;


import javax.xml.ws.Provider;
import javax.xml.ws.WebServiceProvider;
import javax.xml.transform.Source;

@WebServiceProvider( )
public class EchoProvider implements Provider<Source> {

   	@Override
	public Source invoke(Source request) {
		System.out.println("invoke");
		return request;
	}
}