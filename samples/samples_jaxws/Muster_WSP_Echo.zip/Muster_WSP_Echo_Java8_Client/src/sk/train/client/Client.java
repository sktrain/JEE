package sk.train.client;

import java.io.IOException;
import java.net.MalformedURLException;
import javax.xml.namespace.QName;
import javax.xml.soap.MessageFactory;
import javax.xml.soap.SOAPBody;
import javax.xml.soap.SOAPConstants;
import javax.xml.soap.SOAPElement;
import javax.xml.soap.SOAPEnvelope;
import javax.xml.soap.SOAPException;
import javax.xml.soap.SOAPHeader;
import javax.xml.soap.SOAPMessage;
import javax.xml.soap.SOAPPart;
import javax.xml.ws.Dispatch;
import javax.xml.ws.Service;
import javax.xml.ws.soap.SOAPBinding;


public class Client {

	public static void main(String[] args) throws InterruptedException, SOAPException, IOException {

		String endpointUrl = "http://127.0.0.1:8888/EchoProvider";
		
		QName serviceName = new QName("karrer", "EchoService");
		QName portName = new QName("karrer", "EchoServicePort");
				
		/** Service erstellen und mindestens einen Port hinzufügen. **/ 
		Service service = Service.create(serviceName);
		service.addPort(portName, SOAPBinding.SOAP11HTTP_BINDING, endpointUrl);
				
		/** Dispatch-Instanz aus einem Service erstellen **/
		Dispatch<SOAPMessage> dispatch = service.createDispatch(portName, 
		SOAPMessage.class, Service.Mode.MESSAGE);
			
		/** SOAPMessage-Anforderung erstellen **/
		// Anforderungsnachricht erstellen
		MessageFactory mf = MessageFactory.newInstance(SOAPConstants.SOAP_1_1_PROTOCOL);

		// Nachricht erstellen. In diesem Beispiel wird mit SOAPPART gearbeitet.
		SOAPMessage request = mf.createMessage();
		SOAPPart part = request.getSOAPPart();

		// SOAPEnvelope sowie Header- und Hauptteilelemente abrufen
		SOAPEnvelope env = part.getEnvelope();
		SOAPHeader header = env.getHeader();
		SOAPBody body = env.getBody();

		// Nachrichtennutzdaten erstellen
		SOAPElement operation = body.addChildElement("invoke", "ns1",
		 "http://com/ibm/was/wssample/echo/");
		SOAPElement value = operation.addChildElement("arg0");
		value.addTextNode("ping");
		request.saveChanges();

		/** Serviceendpunkt aufrufen **/
		SOAPMessage response = dispatch.invoke(request);
		System.out.println(response);
		response.writeTo(System.out);
		System.out.println();  //flush
		
		
	}

}

