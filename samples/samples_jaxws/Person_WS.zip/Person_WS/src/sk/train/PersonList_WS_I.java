package sk.train;

import javax.jws.WebService;

@WebService
public interface PersonList_WS_I {

	Person getPerson(int i); 

	Person[] getPersonList();

}