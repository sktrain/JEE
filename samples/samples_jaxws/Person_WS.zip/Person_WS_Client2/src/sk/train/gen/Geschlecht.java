
package sk.train.gen;

import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlType;


/**
 * &lt;p&gt;Java-Klasse f�r geschlecht.
 * 
 * &lt;p&gt;Das folgende Schemafragment gibt den erwarteten Content an, der in dieser Klasse enthalten ist.
 * &lt;pre&gt;
 * &amp;lt;simpleType name="geschlecht"&amp;gt;
 *   &amp;lt;restriction base="{http://www.w3.org/2001/XMLSchema}string"&amp;gt;
 *     &amp;lt;enumeration value="W"/&amp;gt;
 *     &amp;lt;enumeration value="M"/&amp;gt;
 *     &amp;lt;enumeration value="U"/&amp;gt;
 *   &amp;lt;/restriction&amp;gt;
 * &amp;lt;/simpleType&amp;gt;
 * &lt;/pre&gt;
 * 
 */
@XmlType(name = "geschlecht")
@XmlEnum
public enum Geschlecht {

    W,
    M,
    U;

    public String value() {
        return name();
    }

    public static Geschlecht fromValue(String v) {
        return valueOf(v);
    }

}
