@javax.xml.bind.annotation.XmlSchema(namespace = "http://train.sk/")
package sk.train.gen;
