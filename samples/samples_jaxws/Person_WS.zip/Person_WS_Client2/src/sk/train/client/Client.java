package sk.train.client;

import java.util.List;
import java.util.Map;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.Future;

import javax.xml.ws.BindingProvider;
import javax.xml.ws.Response;
import javax.xml.ws.soap.SOAPBinding;

import sk.train.gen.GetPersonListResponse;
import sk.train.gen.Person;
import sk.train.gen.PersonListWSI;
import sk.train.gen.PersonListWSService;

//auf der Client-Seite ist noch kein XMLTypeAdapter gesetzt, somit ist das Date in Person ein String!
//die generierte Person-Klasse wurde um eine toString-Methode erweitert
public class Client {

	public static void main(String[] args)  {

			PersonListWSService service = new PersonListWSService();
			
			PersonListWSI proxy = service.getPersonListWSPort();
			
			BindingProvider bp = (BindingProvider) proxy;
			bp.getRequestContext().put(BindingProvider.ENDPOINT_ADDRESS_PROPERTY, "http://localhost:8080/Person_WS/PersonList_WS");
			
			
			List<Person> pl = proxy.getPersonList();
			
			pl.forEach(System.out::println);
			
			Response<GetPersonListResponse> resp =   proxy.getPersonListAsync();
			try {
				List<Person> plasync = resp.get().getReturn();
				plasync.forEach(System.out::println);
			} catch (InterruptedException | ExecutionException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
			
			
	}

}
