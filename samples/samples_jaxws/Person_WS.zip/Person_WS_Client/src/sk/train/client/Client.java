package sk.train.client;

import java.util.List;
import java.util.Map;

import javax.xml.ws.BindingProvider;
import javax.xml.ws.soap.SOAPBinding;   
import sk.train.client.gen.Person;
import sk.train.client.gen.PersonListWSI;
import sk.train.client.gen.PersonListWSService;

//auf der Client-Seite ist noch kein XMLTypeAdapter gesetzt, somit ist das Date in Person ein String!
//die generierte Person-Klasse wurde um eine toString-Methode erweitert
public class Client {

	public static void main(String[] args) {

			PersonListWSService service = new PersonListWSService();
			
			PersonListWSI proxy = service.getPersonListWSPort();
			
			BindingProvider bp = (BindingProvider) proxy;
			bp.getRequestContext().put(BindingProvider.ENDPOINT_ADDRESS_PROPERTY, "http://localhost:8080/Person_WS/PersonList_WS");
			
			List<Person> pl = proxy.getPersonList();
			
			pl.forEach(System.out::println);
			
			//Was passiert bei falschem Index?
//			try {
//				Person p = proxy.getPerson(20);
//			} catch (Exception e) {
//				// TODO Auto-generated catch block
//				System.err.println(e.getClass());
//			}
			
			
			//BindingProvider-Funktionalitaet
			
			System.out.println(bp.getEndpointReference());
			
			Map<String, Object> map = bp.getRequestContext();
			map.forEach(  (s, o)  -> System.out.println(s + " = " + o)     );
			
			
			//javax.xml.ws.soap.SOAPBinding ist korrekt
			SOAPBinding sb = (SOAPBinding) bp.getBinding();
			System.out.println(sb);
			
			
			
	}

}
