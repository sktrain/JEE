JAX-WS-Client :

Diesmal mit dem angepassten Wizard aus Eclipse mit CXF generiert. 
Funktioniert aber nicht mit normalem Java-Projekt und legt immer ein EAR an!
(Eclipse Schwachsinn)