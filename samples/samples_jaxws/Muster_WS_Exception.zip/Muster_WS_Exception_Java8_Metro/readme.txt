JAX-WS-Standalone unter Java 8:

- Die Spezifikation zum Exception-Mapping von JAX-WS (https://download.oracle.com/otndocs/jcp/jaxws-2_3-mrel5-eval-spec/index.html)
scheint nicht so ganz klar zu sein: Bei Metro funktioniert "getFaultInfo()" auch ohne @WebFault, allerdings wird zusätzlich die 
"message" angezeigt. Mit @WebFault wird nur die "FaultInfo" angezeigt.
Bei Apache CXF (Wildfly 24) funktioniert es ohne @WebFault nicht!

-> also immer mit @WebFault.